
import requests
import json

def main():
	weatherData = getWeatherFlowData()
	googleData = getGoogleStatus()

def getWeatherFlowData():
	wfStationID = "46911"
	wfAccessToken = "ad4e4993-334e-4459-83cf-f4511bdbec28"
	observationURL = "https://swd.weatherflow.com/swd/rest/observations/station/{}?token={}".format(wfStationID, wfAccessToken)

	oberservations = requests.get(observationURL)
	print(oberservations.json())
	return oberservations

def getGoogleAuth():
	#tokens and IDs

	googleOAUTHID = "854305848149-qrd4mep639e8pk6448t101tavnenbgve.apps.googleusercontent.com"
	googleRefresh = "1//0fc_ydCTb5GSgCgYIARAAGA8SNwF-L9IrxyvMMXW0y7_wRFv75HFwAAcSACk1sqYMlYj53qdUnRLcKJqIfWOqRBD0sYG43yIvsBI"
	goat = "TTSygcDJqeARhtM7T9J9YbIv"

	refreshURL = "https://www.googleapis.com/oauth2/v4/token?client_id={}&client_secret={}&refresh_token={}&grant_type=refresh_token".format(googleOAUTHID, goat, googleRefresh)

	#retrieve token
	gatJSON = requests.post(refreshURL)
	gatJSON = gatJSON.json()
	gAccessToken = gatJSON.get("access_token")

	if(gAccessToken != None):
		return gAccessToken
	else:
		raise Exception("Authentication Error")

def getGoogleStatus():
	googleAcessToken = getGoogleAuth()
	apiHeaders = {
		'Content-Type': 'application/json',
		'Authorization': 'Bearer {}'.format(googleAcessToken)
	}
	deviceID = "AVPHwEu75kYjAEo3iVR5byvOws96tYDC2Lrpaz32Ajs2PS61PRiJGiI3dkw51h3xI89v2pbcOW-xIc6KlZAxt0ztv7NDhw"

	gapiURL = "https://smartdevicemanagement.googleapis.com/v1/enterprises/39831c32-d4d0-4f03-b6ce-80a04045a2ad/devices/{}".format(deviceID)

	thermoData = requests.get(gapiURL, headers=apiHeaders)
	print(thermoData.json())
	return thermoData

#get lights?

main()